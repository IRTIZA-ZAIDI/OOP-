public class VehicleFactory {
    public VehicleFactory() {
    }
    public Vehicle getVehicle(String vehicle){
        Vehicle v=null;
        if(vehicle.equals("Car")) v=new Car();
        else if(vehicle.equals("Motorcycle")) v=new Motorcycle();
        else System.out.println("Invalid Vehicle ");
        return v;
    }
}
