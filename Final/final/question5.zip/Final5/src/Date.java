public class Date {
    private int Day;
    private int Month;
    private int Year;

    public Date(int day, int month, int year) {
        Day = day;
        Month = month;
        Year = year;
    }

    public boolean compare(Date date){
        if(Day==date.getDay()&&Month==date.getMonth()&&Year==date.getYear()){
            return true;
        }
        return false;
    }
    public String Display(){
        return getDay()+","+getMonth()+","+getYear();
    }

    public int getDay() {
        return Day;
    }

    public void setDay(int day) {
        Day = day;
    }

    public int getMonth() {
        return Month;
    }

    public void setMonth(int month) {
        Month = month;
    }

    public int getYear() {
        return Year;
    }

    public void setYear(int year) {
        Year = year;
    }


}
