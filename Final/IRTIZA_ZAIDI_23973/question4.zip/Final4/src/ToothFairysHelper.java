import com.sun.security.jgss.GSSUtil;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class ToothFairysHelper {

    //returns file
    //reads the file
    public void ReadList(File file) {

        try {
            Scanner sc = new Scanner(file);
            ArrayList<Child> children = new ArrayList<>();
            int necklaces = 0, candies = 0, watches = 0;
            while (sc.hasNext()) {
                //splited by spacing
                String[] line = sc.nextLine().split(" ");
                Child c = new Child(line[0], line[1], line[2], line[3]);

                if (line[3].equals("Bad")) candies++;
                if (line[3].equals("Good")) {
                    if (line[0].equals("M")) {
                        watches++;
                    }
                    if (line[0].equals("F")) {
                        necklaces++;
                    }
                }
                children.add(c);
            }

          CreateFile(children,candies,watches,necklaces);

        } catch (FileNotFoundException e) {
            System.out.println("File does not exist");
            e.printStackTrace();
        }

    }

    //creates file
    private void CreateFile(ArrayList<Child> children, int candies, int watches, int necklaces) {
        try {
            File shoppinglist=new File("ToothFairyShoppingList.txt");
            PrintWriter printWriter = new PrintWriter(shoppinglist);
            for (Child c : children) {
                printWriter.println(c.deserves());
            }
            printWriter.println("Candies: " + candies);
            printWriter.println("Watches: " + watches);
            printWriter.println("Necklaces: " + necklaces);
            printWriter.close();
        } catch (FileNotFoundException e) {
            System.out.println("File does not exist");
            e.printStackTrace();
        }
    }
}
