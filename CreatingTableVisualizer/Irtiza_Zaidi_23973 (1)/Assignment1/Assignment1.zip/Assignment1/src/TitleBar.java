import java.awt.*;

public class TitleBar extends Cell{

    public TitleBar(int x, int y, int width, int height, Color cell_color, Color stroke_color, int stroke, String text) {
       super(x,y,width,height,cell_color,stroke_color,stroke,text);

    }
    public void paintTitle(Graphics g){
        super.paintcells(g);

        g.setColor(stroke_color);
        g.fillRect(Constants.width-width/15 , height/10,8*height/10, 8*height/10);
        g.setColor(Color.RED);
        g.fillRect(Constants.width-width/15 + stroke, height/10+ stroke ,8*height/10- stroke*2, 8*height/10- stroke*2);


    }
}
