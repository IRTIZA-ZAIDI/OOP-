import java.io.*;
import java.util.Scanner;

public class Hospital {
    File info;
//for default constructor
    public Hospital() {
        this.info = new File("PatientsInfo.txt");
    }
//if we give the file
    public Hospital(File info) {
        this.info = info;
    }

    public void addPatient(Patient patient){
        try {
            PrintWriter writer=new PrintWriter(getInfo());
            writer.append(patient.toString());
            writer.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            e.printStackTrace();
        }
    }
    public void deletePatient(Patient patient) {
        try {
            float index = 0;
              Scanner sc=new Scanner(getInfo());
            RandomAccessFile randomAccessFile = new RandomAccessFile(info.getName(), "rw");
            while (randomAccessFile.length() == index) {
                String[] line = new String[]{randomAccessFile.readLine()};
                index = randomAccessFile.getFilePointer();
                String name = line[1];
                int age = Integer.parseInt(line[3]);
                String disease = line[5];
                String[] date = line[7].split(",");
                Date dateOfAdmission = new Date(Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2]));
                date = line[9].split(",");
                Date dateOfDischarge = new Date(Integer.parseInt(date[0]), Integer.parseInt(date[1]), Integer.parseInt(date[2]));

                Patient p = new Patient(name, age, disease, dateOfAdmission, dateOfDischarge);
                if (p == patient) {
                    randomAccessFile.seek((long) index);
                    randomAccessFile.write(-1);

                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("File not found");
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    public void displayall() {

        try {
            Scanner sc = new Scanner(getInfo);
            while (sc.hasNext()) {
                System.out.println(sc.nextLine());
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
            public void setInfo (File info){
                this.info = info;
            }

            public File getInfo  {
                return info;
            }
        }
}
