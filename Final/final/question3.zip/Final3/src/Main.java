import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        VehicleFactory vehicleFactory=new VehicleFactory();
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter Motor of your type: Car or Motorcycle");
        String vehicle=sc.next();

        try {
            Vehicle v = vehicleFactory.getVehicle(vehicle);
            v.start();
            v.stop();
        } catch (NullPointerException e) {
            e.printStackTrace();
        }

    }
}
