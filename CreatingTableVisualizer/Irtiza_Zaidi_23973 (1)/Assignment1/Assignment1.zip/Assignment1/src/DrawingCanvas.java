
import java.awt.*;

public class DrawingCanvas extends Canvas {

    public void paint(Graphics g)
    {
        Table table=new Table();
        table.paintTitle(g);








    }
}


