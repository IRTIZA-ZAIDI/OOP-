public class Cube extends Cuboid{
    public Cube(float length) {
        super(length, length, length);
    }
    public String getShapeType() {
        return "Cube";
    }

    @Override
    public String toString() {
        return "Cube{Each length= " + getLength()+"}";
    }
}
