import java.io.File;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {

        File file=new File("C:\\Users\\exam21\\IdeaProjects\\Final4\\src\\ToothFairyList");
        ToothFairysHelper toothFairysHelper=new ToothFairysHelper();
        toothFairysHelper.ReadList(file);
        }
    }
