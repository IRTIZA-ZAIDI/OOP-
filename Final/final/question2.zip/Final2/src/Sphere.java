public class Sphere implements Shape{
    private float radius;

    public Sphere(float radius) {
        this.radius = radius;
    }

    public float getRadius() {
        return radius;
    }

    @Override
    public String toString() {
        return "Sphere{" +
                "radius=" + radius +
                '}';
    }

    @Override
    public float getVolume() {
        return (float) ((4*(Math.PI*radius*getRadius()*getRadius()))/3);
    }

    @Override
    public String getShapeType() {
        return "Sphere";
    }

    @Override
    public float getSurfaceArea() {
        return (float) (4*Math.PI*getRadius()*getRadius());
    }
}

