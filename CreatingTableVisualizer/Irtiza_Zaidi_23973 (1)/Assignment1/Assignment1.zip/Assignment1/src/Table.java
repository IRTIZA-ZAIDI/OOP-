import java.awt.*;
import java.awt.Rectangle;
import java.awt.image.ImageObserver;
import java.text.AttributedCharacterIterator;

public class Table  {

   private TitleBar title;
   private Cell [] cell;

  public Table() {


  }
  public void paintTitle(Graphics g) {

     title=new TitleBar(0,0,Constants.width,Constants.height/17,Color.BLACK,Color.GRAY,Constants.strokesize, "Data Table");
      title.paintTitle(g);

      cell = new Cell[75];
      int x = 0, y = 0;
      Color p;

      for (int j = 0; j < 15; j++) {
          x = 0;
          for (int i = 0; i < 5; i++) {
              if(j==0) {
                 p=new Color(156,204,255);
              }
              else {
                 p=Color.GRAY;
              }
              cell[i + j] = new Cell(0+x,Constants.cell_height+y-Constants.strokesize, Constants.cell_width, Constants.cell_height,p, Color.BLUE, Constants.strokesize, "default");
              cell[i + j].paintcells(g);
              x = x + Constants.cell_width;
          }
          y = y +Constants.cell_height;

      }
  }
  }
