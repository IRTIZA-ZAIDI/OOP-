public class Cylinder implements Shape {
    private float radius;
    private float height;

    public Cylinder(float radius, float height) {
        this.radius = radius;
        this.height = height;
    }

    public float getRadius() {
        return radius;
    }

    public float getHeight() {
        return height;
    }

    @Override
    public String toString() {
        return "Cylinder{" +
                "radius=" + radius +
                ", height=" + height +
                '}';
    }

    @Override
    public float getVolume() {
        return (float) (getHeight()*Math.PI*getRadius()*getRadius());
    }

    @Override
    public String getShapeType() {
        return "Cylinder";
    }

    @Override
    public float getSurfaceArea() {
        return (float) (2*Math.PI*getRadius()*(getRadius()+getHeight()));
    }
}
