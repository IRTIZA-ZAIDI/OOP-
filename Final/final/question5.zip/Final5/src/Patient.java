
public class Patient {
    private String name;
    private int age;
    private String disease;
    private Date DateOfAdmission;
    private Date DateOfDischarge;


    public Patient(String name, int age, String disease, Date date, Date date1) {
        this.name = name;
        this.age = age;
        this.disease = disease;
        DateOfAdmission = date;
        DateOfDischarge = date1;
    }

    public Patient save(){
        return this;
    }


    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }

    @Override
    public String toString() {
        return "Name= "+getName() + " Age= "+getAge()+" Disease= "+getDisease()+" DateOfAdmission= "+getDateOfAdmission().Display()+" DateOfDischarge= "+getDateOfDischarge().Display();

    }

//    public boolean Compare(Patient p){
//        if(name.compareTo(p.getName()) && (age == p.getAge()) && disease.compareTo(p.disease) && DateOfAdmission.compare(p.getDateOfAdmission()) && DateOfDischarge.compare(p.getDateOfDischarge())) {
//            ;
//        }
//    }




    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getDisease() {
        return disease;
    }

    public void setDisease(String disease) {
        this.disease = disease;
    }

    public Date getDateOfAdmission() {
        return DateOfAdmission;
    }

    public void setDateOfAdmission(Date dateOfAdmission) {
        DateOfAdmission = dateOfAdmission;
    }

    public Date getDateOfDischarge() {
        return DateOfDischarge;
    }

    public void setDateOfDischarge(Date dateOfDischarge) {
        DateOfDischarge = dateOfDischarge;
    }
}
