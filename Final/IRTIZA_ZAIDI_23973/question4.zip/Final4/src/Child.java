public class Child {
    private String gender;
    private String lastname;
    private String firstname;
    private String status;


    public Child(String gender, String lastname, String firstname, String status) {
        this.gender = gender;
        this.lastname = lastname;
        this.firstname = firstname;
        this.status = status;
    }

    public String getGender() {
        return gender;
    }

    public String getLastname() {
        return lastname;
    }

    public String getFirstname() {
        return firstname;
    }

    public String gift(){
        if(status.equals("Bad")) {
            return "Candy";
        }
        if(status.equals("Good")){
            if(getGender().equals("M")){
                return "Watch";
            }
            if(getGender().equals("F")){
                return  "Necklace";
            }
        }
        return "";
    }
    public String deserves(){
        return getLastname()+", "+getFirstname()+" "+gift();
    }
}
