public interface Shape {
    public float getVolume();
    public String getShapeType();
    public float getSurfaceArea();
}
