import java.awt.*;

public class Cell {
    protected Point topleft ;
    protected int width;
    protected int height;
    protected int stroke;
    protected Color cell_color;
    protected Color stroke_color;
    protected String text;
    protected Font font;
    protected int fontSize;
    protected int fontStyle;

    public Cell(int x, int y, int width, int height, Color cell_color, Color stroke_color, int stroke, String text){
        this.topleft=new Point(x,y);
        this.width=width;
        this.height=height;
        this.cell_color=cell_color;
        this.stroke_color=stroke_color;
        this.stroke=stroke;
        this.text=text;

    }

   public void paintcells(Graphics g){
       g.setColor(stroke_color);
       g.fillRect(topleft.x , topleft.y , width, height);
       g.setColor(cell_color);
       g.fillRect(topleft.x + stroke , topleft.y + stroke, width - stroke*2, height - stroke*2);

       g.setColor(Color.WHITE);
       this.fontSize=(width*height);
       while (fontSize>height) fontSize=fontSize/2;

       this.fontStyle=font.PLAIN;
       font=new Font("Times New Roman",fontStyle,fontSize);
       g.setFont(font);
       FontMetrics metrics = g.getFontMetrics();
       int textHeight = metrics.getAscent() - metrics.getDescent();
       g.drawString(this.text,topleft.x+(width)/15- stroke, topleft.y+3*textHeight/2);




    }


    public void paintHighlighted(Graphics g){

    }



}
