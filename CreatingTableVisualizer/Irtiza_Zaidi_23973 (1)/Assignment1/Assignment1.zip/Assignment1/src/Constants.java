public class Constants {
    static final int width = 800;
    static final int height = 700;
    static final int strokesize=3;

    static int cell_width=width/5;
    static int cell_height=height/17;




}
