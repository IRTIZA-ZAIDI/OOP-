import java.util.Scanner;

public class Q1_manager {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Input number: ");
        int num=sc.nextInt();
            try {
                validateInput(num);
                System.out.println(num);
            } catch (InvalidInputException e) {
                e.printStackTrace();
            }
        }
    public static int validateInput(int num) throws InvalidInputException{
        if(num<=0) {
           throw new InvalidInputException("Wrong input");
        }
        else return num;

    }
}
